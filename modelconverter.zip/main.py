# coding:utf-8
import json
import os

# глобальные переменные
delNodes = ['$schema', '$comment','dependencies'] # удаляемые блоки
refNodes = ['$ref'] # блоки, где меняем ссылки
dir_root =r'C:\_GITLAB\modelconverter' # корневой каталог
dir_schemes_name = dir_root + r'\definitions' # каталог обработки файлов схем модели
dir_rest_schemes_name = dir_root + r'\paths\schemes' # каталог обработки файлов схем рест запросов
dir_rest_controllers_name = dir_root + r'\paths' # каталог обработки файлов схем рест контроллеров
postfix = 'Dto'


# Удаление объектов по ключу
def remove_key(d, targetkey):
    if not isinstance(d, (dict, list)): return d
    elif isinstance(d, list): return [v for v in (remove_key(v, targetkey) for v in d)]
    else: return {k: v for k, v in ((k, remove_key(v, targetkey)) for k, v in d.items()) if k not in targetkey}


# Замена $ref
def change_ref(d, targetkey, postfix):
    if not isinstance(d, (dict, list)):
        if 'file:' in str(d): return '#/definitions/' + ((str.split(d, '/')[-1]).split('.')[0]+postfix)
        return d
    elif isinstance(d, list): return [v for v in (change_ref(v, targetkey, postfix) for v in d)]
    else: return {k: v for k, v in ((k, change_ref(v, targetkey,postfix)) for k, v in d.items())}


# объединяем файлы json в модель swagger
def add_json_to_model(dir_schemes_name, f, postfix):
    global model, delNodes, refNodes
    if f.endswith('.json'):
        try:
            with open(dir_schemes_name+"\\"+f, encoding='utf-8') as fh:
                dto = remove_key(json.load(fh), delNodes)
                dto = change_ref(dto, refNodes,postfix)
        except ValueError as e: return False
        model["definitions"][dto["title"]+postfix] = dto
        return True
    return False


# объединяем файлы json в модель swagger (контроллеры + REST запросы)
def add_controllers_to_model(dir_schemes_name, f):
    global model
    if f.endswith('.json'):
        try:
            with open(dir_schemes_name+"\\"+f, encoding='utf-8') as fh:
                controller_json = json.load(fh)
                tags = controller_json['tags']
                paths = controller_json['paths']
        except ValueError as e: return False
        model["tags"] += tags
        model["paths"].update(paths)
        return True
    return False


# добавляем заголовок в результирующий файл JSON модели
with open("header.json", encoding='utf-8') as fh:
    model = json.load(fh)

# Обрабатываем схемы модели
json_model_files = [f for f in os.listdir(dir_schemes_name) if add_json_to_model(dir_schemes_name, f, postfix)]

# Обрабатываем схемы рест API
json_schemes_files = [f for f in os.listdir(dir_rest_schemes_name) if add_json_to_model(dir_rest_schemes_name, f, '')]

# Добаваляем контроллер (для примера GET 10 Application)
json_controller_files = [f for f in os.listdir(dir_rest_controllers_name) if add_controllers_to_model(dir_rest_controllers_name,f)]
with open("model.json", 'w', encoding='utf-8') as outfile:
    json.dump(model, outfile, indent=2, ensure_ascii=False)


